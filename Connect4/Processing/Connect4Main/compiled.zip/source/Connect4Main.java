import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Random; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Connect4Main extends PApplet {


Connect4Game game = new Connect4Game(7, 6);

Player red = new Human(game);
Player yellow = new MiniMaxAgent(game);

boolean redturn = true;
int framesElapsed = 0;

public void setup() {
  

  game.setRed(red);
  game.setYellow(yellow);

  game.render();
}

public void draw() {
  game.render();

  Player w = game.getWinner();
  if (game.isFull() || w != null) {

    //Game Over
    game.highlightWinner((int)(sin(framesElapsed/3)*255));
    if (framesElapsed <= 0 && w != null) {
      w.wins++;
      println("Winner: " + w);
      println("Red: " + red.wins + " Yellow: " + yellow.wins);
      framesElapsed = 1;
    } else if (framesElapsed < 200) {
      framesElapsed++;
    } else {
      game.reset();
      framesElapsed = 0;
    }
  } else {

    //Game In Progress
    if (game.play(redturn ? red : yellow)) {
      redturn = !redturn;
    }
  }
}
class Connect4Game {

  int w, h;
  Player y, r;
  int[][] board;

  public Connect4Game(int w, int h) {
    this.w = w;
    this.h = h;

    board = new int[h][w];
    Helpers.fillMat(board, 0);
  }

  public void setYellow(Player p) {
    y = p;
    y.setRed(false);
  }

  public void setRed(Player p) {
    r = p;
    r.setRed(true);
  }

  public boolean play(Player p) {
    int mov = p.getMove();
    if (mov > -1) {
      return move(mov, p.isRed ? 1:2);
    }
    return false;
  }

  private boolean move(int col, int p) {
    if (board[0][col] == 0) {
      board[Helpers.nextRow(board, col)][col] = p;
      return true;
    }
    return move((int)(Math.random() * w), p); //Invalid Move -> Random Move
  }

  public Player getWinner() {
    if (Helpers.mostVertical(board, 1) == 4 || 
      Helpers.mostHorizontal(board, 1) == 4 ||
      Helpers.mostIncDiag(board, 1) == 4 ||
      Helpers.mostDecDiag(board, 1) == 4) {
      return r;
    } else if (Helpers.mostVertical(board, 2) == 4 || 
      Helpers.mostHorizontal(board, 2) == 4 ||
      Helpers.mostIncDiag(board, 2) == 4 ||
      Helpers.mostDecDiag(board, 2) == 4) {
      return y;
    }
    return null;
  }

  public void render() {

    background(0xff3F51B5);
    noStroke();
    ellipseMode(CORNER);
    for (int r = 0; r < h; r++) {
      for (int c = 0; c < w; c++) {
        if (board[r][c] == 1) {
          fill(0xffE53935);//Red
        } else if (board[r][c] == 2) {
          fill(0xffFFEB3B);//Yellow
        } else {
          fill(0xffEEEEEE);//White
        }
        renderSlot(r, c);
      }
    }
  }

  private void renderSlot(int r, int c) {
    int xdis = width / w;
    int ydis = height / h;
    ellipse(c*xdis + 8, r*ydis + 8, xdis-16, ydis-16);
  }

  public void highlightWinner(int alpha) {
    fill(255, 0, 255);
    for (int r = 0; r < h; r++) {
      for (int c = 0; c < w; c++) {
        if (board[r][c] != 0) {

          if (board[r][c] == 1) {
            fill(0xffff3d00, alpha);
          } else {
            fill(0xffff6f00, alpha);
          }

          if (r + 3 < h) {
            if (board[r][c] == board[r + 1][c] && board[r][c] == board[r + 2][c] && board[r][c] == board[r + 3][c]) {
              renderSlot(r, c);
              renderSlot(r + 1, c);
              renderSlot(r + 2, c);
              renderSlot(r + 3, c);
            }
          }
          if (c + 3 < w) {
            if (board[r][c] == board[r][c + 1] && board[r][c] == board[r][c + 2] && board[r][c] == board[r][c + 3]) {
              renderSlot(r, c);
              renderSlot(r, c + 1);
              renderSlot(r, c + 2);
              renderSlot(r, c + 3);
            }
          }
          if (c + 3 < w && r + 3 < h) {
            if (board[r][c] == board[r + 1][c + 1] && board[r][c] == board[r + 2][c + 2] && board[r][c] == board[r + 3][c + 3]) {
              renderSlot(r, c);
              renderSlot(r + 1, c + 1);
              renderSlot(r + 2, c + 2);
              renderSlot(r + 3, c + 3);
            }
          }
          if (c > 2 && r + 3 < h) {
            if (board[r][c] == board[r + 1][c - 1] && board[r][c] == board[r + 2][c - 2] && board[r][c] == board[r + 3][c - 3]) {
              renderSlot(r, c);
              renderSlot(r + 1, c - 1);
              renderSlot(r + 2, c - 2);
              renderSlot(r + 3, c - 3);
            }
          }
        }
      }
    }
  }

  public void reset() {
    Helpers.fillMat(board, 0);
  }

  public boolean isEmpty() {
    for (int c = 0; c < w; c++) {
      if (board[h-1][c] != 0) {
        return false;
      }
    }
    return true;
  }

  public boolean isFull() {
    for (int c = 0; c < w; c++) {
      if (board[0][c] == 0) {
        return false;
      }
    }
    return true;
  }
}


class EnemyAgent extends Player {

  boolean iAmRed;
  GameWrapper myGame;
  Random r = new Random();

  public EnemyAgent(Connect4Game g) {
    super(g);
    iAmRed = isRed;
    myGame = new GameWrapper(super.game);
  }

  private class GameWrapper {

    Connect4Game game;

    public GameWrapper(Connect4Game g) {
      game = g;
    }

    public Connect4Column getColumn(int col) {
      return new Connect4Column(game.board, col);
    }

    public int getRowCount() {
      return game.h;
    }

    public int getColumnCount() {
      return game.w;
    }
  }

  private class Connect4Column {

    int[] values;

    public Connect4Column(int[][] board, int col) {
      values = new int[board[0].length];
      for (int r = 0; r < board.length; r++) {
        values[r] = board[r][col];
      }
    }

    public Connect4Slot getSlot(int r) {
      return new Connect4Slot(values[r]);
    }

    public boolean getIsFull() {
      return values[0] != 0;
    }

    public int getRowCount() {
      return values.length;
    }
  }

  private class Connect4Slot {

    int v;

    public Connect4Slot(int n) {
      v = n;
    }

    public boolean getIsRed() {
      return v == 1;
    }

    public boolean getIsFilled() {
      return v != 0;
    }
  }

  public int getMove() {
    int count;
    int rand;
    if (!iAmRed) {
      count = 0;
      rand = (int) (Math.random() * 2d);
      if (theyCanWin() > -1) {
        return theyCanWin();
      } else if (iCanWin() > -1) {
        return iCanWin();
      } else if (myGame.getColumn(3).getSlot(myGame.getRowCount() - 1).getIsFilled() && myGame.getColumn(3).getSlot(myGame.getRowCount() - 1).getIsRed() && !myGame.getColumn(2).getSlot(myGame.getRowCount() - 1).getIsFilled()) {
        return 2;
      } else if (myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsFilled() && myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsRed() && myGame.getColumn(4).getSlot(myGame.getRowCount() - 2).getIsFilled() && myGame.getColumn(4).getSlot(myGame.getRowCount() - 2).getIsRed() && getLowestEmptyIndex(myGame.getColumn(2)) == myGame.getRowCount() - 2 && theyCanWinOffOfMyPlay(2) == -1 && ICanWinOffOfMyPlay(2) == -1) {
        return 2;
      } else if (myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsFilled() && myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsRed() && myGame.getColumn(2).getSlot(myGame.getRowCount() - 2).getIsFilled() && myGame.getColumn(2).getSlot(myGame.getRowCount() - 2).getIsRed() && getLowestEmptyIndex(myGame.getColumn(4)) == myGame.getRowCount() - 2 && theyCanWinOffOfMyPlay(4) == -1 && ICanWinOffOfMyPlay(4) == -1) {
        return 4;
      } else if (getLowestEmptyIndex(myGame.getColumn(3)) > 0 && theyCanWinOffOfMyPlay(3) == -1 && ICanWinOffOfMyPlay(3) == -1) {
        return 3;
      } else if (rand % 2 == 0 && getLowestEmptyIndex(myGame.getColumn(2)) > 0 && theyCanWinOffOfMyPlay(2) == -1 && ICanWinOffOfMyPlay(2) == -1 && setsUp3fromCol2(2) == 2) {
        return 2;
      } else if (rand % 2 == 1 && getLowestEmptyIndex(myGame.getColumn(4)) > 0 && theyCanWinOffOfMyPlay(4) == -1 && ICanWinOffOfMyPlay(4) == -1 && setsUp3fromCol4(4) == 4) {
        return 4;
      } else if (rand % 2 == 0 && getLowestEmptyIndex(myGame.getColumn(1)) > 0 && theyCanWinOffOfMyPlay(1) == -1 && ICanWinOffOfMyPlay(1) == -1) {
        return 1;
      } else if (rand % 2 == 1 && getLowestEmptyIndex(myGame.getColumn(5)) > 0 && theyCanWinOffOfMyPlay(5) == -1 && ICanWinOffOfMyPlay(5) == -1) {
        return 5;
      } else {
        count = 0;
        do {
          if (count >= 200) {
            break;
          }
          int i = randomMove();
          if (i != theyCanWinOffOfMyPlay(i) && ICanWinOffOfMyPlay(i) != i) {
            return i;
          }
          count++;
        } while (true);
      }
      if (count == 200) {
        for (int x = 0; x < myGame.getColumnCount(); x++) {
          if (getLowestEmptyIndex(myGame.getColumn(x)) != -1) {
            return x;
          }
        }

        return randomMove();
      }
    }
    count = 0;
    rand = (int) (Math.random() * 2d);
    if (iCanWin() > -1) {
      return iCanWin();
    } else if (theyCanWin() > -1) {
      return theyCanWin();
    } else if (myGame.getColumn(3).getSlot(myGame.getRowCount() - 1).getIsFilled() && !myGame.getColumn(3).getSlot(myGame.getRowCount() - 1).getIsRed() && !myGame.getColumn(2).getSlot(myGame.getRowCount() - 1).getIsFilled()) {
      return 2;
    } else if (myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsFilled() && !myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsRed() && myGame.getColumn(4).getSlot(myGame.getRowCount() - 2).getIsFilled() && !myGame.getColumn(4).getSlot(myGame.getRowCount() - 2).getIsRed() && getLowestEmptyIndex(myGame.getColumn(2)) == myGame.getRowCount() - 2 && theyCanWinOffOfMyPlay(2) == -1 && ICanWinOffOfMyPlay(2) == -1) {
      return 2;
    } else if (myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsFilled() && !myGame.getColumn(3).getSlot(myGame.getRowCount() - 2).getIsRed() && myGame.getColumn(2).getSlot(myGame.getRowCount() - 2).getIsFilled() && !myGame.getColumn(2).getSlot(myGame.getRowCount() - 2).getIsRed() && getLowestEmptyIndex(myGame.getColumn(4)) == myGame.getRowCount() - 2 && theyCanWinOffOfMyPlay(4) == -1 && ICanWinOffOfMyPlay(4) == -1) {
      return 4;
    } else if (getLowestEmptyIndex(myGame.getColumn(3)) > 0 && theyCanWinOffOfMyPlay(3) == -1 && ICanWinOffOfMyPlay(3) == -1) {
      return 3;
    } else if (rand % 2 == 0 && getLowestEmptyIndex(myGame.getColumn(2)) > 0 && theyCanWinOffOfMyPlay(2) == -1 && ICanWinOffOfMyPlay(2) == -1 && setsUp3fromCol2(2) == 2) {
      return 2;
    } else if (rand % 2 == 1 && getLowestEmptyIndex(myGame.getColumn(4)) > 0 && theyCanWinOffOfMyPlay(4) == -1 && ICanWinOffOfMyPlay(4) == -1 && setsUp3fromCol4(4) == 4) {
      return 4;
    } else if (rand % 2 == 0 && getLowestEmptyIndex(myGame.getColumn(1)) > 0 && theyCanWinOffOfMyPlay(1) == -1 && ICanWinOffOfMyPlay(1) == -1) {
      return 1;
    } else if (rand % 2 == 1 && getLowestEmptyIndex(myGame.getColumn(5)) > 0 && theyCanWinOffOfMyPlay(5) == -1 && ICanWinOffOfMyPlay(5) == -1) {
      return 5;
    } else {
      count = 0;
      do {
        if (count >= 200) {
          break;
        }
        int i = randomMove();
        if (i != theyCanWinOffOfMyPlay(i) && ICanWinOffOfMyPlay(i) != i) {
          return i;
        }
        count++;
      } while (true);
    }
    if (count == 200) {
      for (int x = 0; x < myGame.getColumnCount(); x++) {
        if (getLowestEmptyIndex(myGame.getColumn(x)) != -1) {
          return x;
        }
      }

      return randomMove();
    }
    return 0;
  }

  public int setsUp3fromCol2(int spot) {
    int lowest = getLowestEmptyIndex(myGame.getColumn(spot));
    return lowest - 1 <= 3 || !myGame.getColumn(spot + 1).getSlot(lowest - 1).getIsFilled() || myGame.getColumn(spot + 1).getSlot(lowest - 1).getIsRed() || !myGame.getColumn(spot + 2).getSlot(lowest - 1).getIsFilled() || myGame.getColumn(spot + 2).getSlot(lowest - 1).getIsRed() ? 2 : -1;
  }

  public int setsUp3fromCol4(int spot) {
    int lowest = getLowestEmptyIndex(myGame.getColumn(spot));
    return lowest - 1 <= 3 || !myGame.getColumn(spot - 1).getSlot(lowest - 1).getIsFilled() || myGame.getColumn(spot - 1).getSlot(lowest - 1).getIsRed() || !myGame.getColumn(spot - 2).getSlot(lowest - 1).getIsFilled() || myGame.getColumn(spot - 2).getSlot(lowest - 1).getIsRed() ? 4 : -1;
  }

  public int getLowestEmptyIndex(Connect4Column column) {
    int lowestEmptySlot = -1;
    for (int i = 0; i < column.getRowCount(); i++) {
      if (!column.getSlot(i).getIsFilled()) {
        lowestEmptySlot = i;
      }
    }

    return lowestEmptySlot;
  }

  public int randomMove() {
    int i;
    for (i = r.nextInt(myGame.getColumnCount()); getLowestEmptyIndex(myGame.getColumn(i)) == -1; i = r.nextInt(myGame.getColumnCount()));
    return i;
  }

  public int iCanWin() {
    for (int i = 0; i < myGame.getColumnCount(); i++) {
      Connect4Column test = myGame.getColumn(i);
      if (test.getIsFull()) {
        continue;
      }
      int count = 0;
      for (int j = 0; j < test.getRowCount(); j++) {
        if (!test.getSlot(j).getIsFilled()) {
          continue;
        }
        if (!test.getSlot(j).getIsRed()) {
          break;
        }
        if (++count == 3) {
          return i;
        }
      }
    }

    for (int i = 0; i < myGame.getColumnCount(); i++) {
      Connect4Column test = myGame.getColumn(i);
      if (test.getIsFull()) {
        continue;
      }
      int spot = test.getRowCount() - 1;
      int j = 0;
      do {
        if (j >= test.getRowCount()) {
          break;
        }
        if (test.getSlot(j).getIsFilled()) {
          spot = j - 1;
          break;
        }
        j++;
      } while (true);
      int count = 0;
      for (int col = i - 1; col >= 0 && myGame.getColumn(col).getSlot(spot).getIsFilled() && myGame.getColumn(col).getSlot(spot).getIsRed(); col--) {
        count++;
      }

      for (int col = i + 1; col < myGame.getColumnCount() && myGame.getColumn(col).getSlot(spot).getIsFilled() && myGame.getColumn(col).getSlot(spot).getIsRed(); col++) {
        count++;
      }

      if (count >= 3) {
        return i;
      }
    }

    for (int i = 0; i < myGame.getColumnCount(); i++) {
      Connect4Column test = myGame.getColumn(i);
      int emptySpot = getLowestEmptyIndex(test);
      if (emptySpot == -1) {
        continue;
      }
      int count = 0;
      int col = i - 1;
      int row;
      for (row = emptySpot - 1; col >= 0 && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
        count++;
        col--;
      }

      row = emptySpot + 1;
      for (col = i + 1; col < myGame.getColumnCount() && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
        count++;
        col++;
      }

      if (count >= 3) {
        return i;
      }
      count = 0;
      col = i - 1;
      for (row = emptySpot + 1; col >= 0 && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
        count++;
        col--;
      }

      row = emptySpot - 1;
      for (col = i + 1; col < myGame.getColumnCount() && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
        count++;
        col++;
      }

      if (count >= 3) {
        return i;
      }
    }

    return -1;
  }

  public int theyCanWin() {
    for (int i = 0; i < myGame.getColumnCount(); i++) {
      Connect4Column test = myGame.getColumn(i);
      if (test.getIsFull()) {
        continue;
      }
      int count = 0;
      for (int j = 0; j < test.getRowCount(); j++) {
        if (!test.getSlot(j).getIsFilled()) {
          continue;
        }
        if (test.getSlot(j).getIsRed()) {
          break;
        }
        if (++count == 3) {
          return i;
        }
      }
    }

    for (int i = 0; i < myGame.getColumnCount(); i++) {
      Connect4Column test = myGame.getColumn(i);
      if (test.getIsFull()) {
        continue;
      }
      int spot = test.getRowCount() - 1;
      int j = 0;
      do {
        if (j >= test.getRowCount()) {
          break;
        }
        if (test.getSlot(j).getIsFilled()) {
          spot = j - 1;
          break;
        }
        j++;
      } while (true);
      int count = 0;
      for (int col = i - 1; col >= 0 && myGame.getColumn(col).getSlot(spot).getIsFilled() && !myGame.getColumn(col).getSlot(spot).getIsRed(); col--) {
        count++;
      }

      for (int col = i + 1; col < myGame.getColumnCount() && myGame.getColumn(col).getSlot(spot).getIsFilled() && !myGame.getColumn(col).getSlot(spot).getIsRed(); col++) {
        count++;
      }

      if (count >= 3) {
        return i;
      }
    }

    for (int i = 0; i < myGame.getColumnCount(); i++) {
      Connect4Column test = myGame.getColumn(i);
      int emptySpot = getLowestEmptyIndex(test);
      if (emptySpot == -1) {
        continue;
      }
      int count = 0;
      int col = i - 1;
      int row;
      for (row = emptySpot - 1; col >= 0 && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
        count++;
        col--;
      }

      row = emptySpot + 1;
      for (col = i + 1; col < myGame.getColumnCount() && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
        count++;
        col++;
      }

      if (count >= 3) {
        return i;
      }
      count = 0;
      col = i - 1;
      for (row = emptySpot + 1; col >= 0 && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
        count++;
        col--;
      }

      row = emptySpot - 1;
      for (col = i + 1; col < myGame.getColumnCount() && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
        count++;
        col++;
      }

      if (count >= 3) {
        return i;
      }
    }

    return -1;
  }

  public int theyCanWinOffOfMyPlay(int i) {
    Connect4Column test = myGame.getColumn(i);
    int emptySpot = getLowestEmptyIndex(test);
    if (emptySpot == -1 || emptySpot == 0) {
      return -1;
    }
    emptySpot--;
    int count = 0;
    int col = i - 1;
    int row;
    for (row = emptySpot - 1; col >= 0 && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
      count++;
      col--;
    }

    row = emptySpot + 1;
    for (col = i + 1; col < myGame.getColumnCount() && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
      count++;
      col++;
    }

    if (count >= 3) {
      return i;
    }
    count = 0;
    col = i - 1;
    for (row = emptySpot + 1; col >= 0 && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
      count++;
      col--;
    }

    row = emptySpot - 1;
    for (col = i + 1; col < myGame.getColumnCount() && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
      count++;
      col++;
    }

    if (count >= 3) {
      return i;
    }
    row = emptySpot;
    count = 0;
    for (col = i - 1; col >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); col--) {
      count++;
    }

    for (col = i + 1; col < myGame.getColumnCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && !myGame.getColumn(col).getSlot(row).getIsRed(); col++) {
      count++;
    }

    if (count >= 3) {
      return i;
    } else {
      return -1;
    }
  }

  public int ICanWinOffOfMyPlay(int i) {
    Connect4Column test = myGame.getColumn(i);
    int emptySpot = getLowestEmptyIndex(test);
    if (emptySpot == -1 || emptySpot == 0) {
      return -1;
    }
    emptySpot--;
    int count = 0;
    int col = i - 1;
    int row;
    for (row = emptySpot - 1; col >= 0 && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
      count++;
      col--;
    }

    row = emptySpot + 1;
    for (col = i + 1; col < myGame.getColumnCount() && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
      count++;
      col++;
    }

    if (count >= 3) {
      return i;
    }
    count = 0;
    col = i - 1;
    for (row = emptySpot + 1; col >= 0 && row < test.getRowCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row++) {
      count++;
      col--;
    }

    row = emptySpot - 1;
    for (col = i + 1; col < myGame.getColumnCount() && row >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); row--) {
      count++;
      col++;
    }

    if (count >= 3) {
      return i;
    }
    row = emptySpot;
    count = 0;
    for (col = i - 1; col >= 0 && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); col--) {
      count++;
    }

    for (col = i + 1; col < myGame.getColumnCount() && myGame.getColumn(col).getSlot(row).getIsFilled() && myGame.getColumn(col).getSlot(row).getIsRed(); col++) {
      count++;
    }

    if (count >= 3) {
      return i;
    } else {
      return -1;
    }
  }
}
static class Helpers {

  public static int mostVertical(int[][] board, int p) {
    int most = 0;
    for (int c = 0; c < board[0].length; c++) {
      for (int r = 0; r < board.length; r++) {
        if (board[r][c] == p) {
          int count = 1;
          while (r + count < board.length && board[r + count][c] == p) {
            count++;
          }
          most = max(most, count);
        }
      }
    }
    return most;
  }

  public static int mostHorizontal(int[][] board, int p) {
    int most = 0;
    for (int r = 0; r < board.length; r++) {
      for (int c = 0; c < board[0].length; c++) {
        if (board[r][c] == p) {
          int count = 1;
          while (c + count < board[0].length && board[r][c + count] == p) {
            count++;
          }
          most = max(most, count);
        }
      }
    }
    return most;
  }

  public static int mostIncDiag(int[][] board, int p) {
    int most = 0;
    for (int r = 0; r < board.length; r++) {
      for (int c = 0; c < board[0].length; c++) {
        int rr = r, cc = c, count = 0;

        while (rr > 0 && cc < board[rr].length && board[rr][cc] == p) {
          rr--;
          cc++;
          count++;
        }
        most = max(most, count);
      }
    }
    return most;
  }

  public static int mostDecDiag(int[][] board, int p) {
    int most = 0;
    for (int r = 0; r < board.length; r++) {
      for (int c = 0; c < board[0].length; c++) {
        int rr = r, cc = c, count = 0;
        while (rr < board.length && cc < board[rr].length && board[rr][cc] == p) {
          rr++;
          cc++;
          count++;
        }
        most = max(most, count);
      }
    }
    return most;
  }

  public static int nextRow(int[][] board, int c) {
    if (board[0][c] == 0) {
      int row = 0;
      while (row < board.length && board[row][c] == 0) {
        row++;
      }
      return row-1;
    }
    return -1;
  }

  public static int sum(int[] v) {
    int s = 0;
    for (int j : v) {
      s += j;
    }
    return s;
  }

  public static int count(int[] v, int n) {
    int c = 0;
    for (int j : v) {
      if (j == n) {
        c++;
      }
    }
    return c;
  }

  public static boolean containsAtLeast(int[] v, int n) {
    for (int j : v) {
      if (j >= n) {
        return true;
      }
    }
    return false;
  }

  public static void fillMat(int[][] board, int v) {
    for (int[] row : board) {
      for (int c = 0; c < row.length; c++) {
        row[c] = v;
      }
    }
  }

  public static int[][] copyMat(int[][] board) {
    int[][] m = new int[board.length][board[0].length];
    for (int r = 0; r < board.length; r++) {
      for (int c = 0; c < board[r].length; c++) {
        m[r][c] = board[r][c];
      }
    }
    return m;
  }

  public static String showMat(int[][] board) {
    String s = "";
    for (int[] row : board) {
      for (int c : row) {
        s += c + " ";
      }
      s += "\n";
    }
    return s;
  }

  public static String indent(int v, int i) {
    String s = "";
    for (; i >= 0; i--) {
      s += " ";
    }
    return s + v;
  }
}

class Human extends Player {

  public Human(Connect4Game g) {
    super(g);
  }

  public int getMove() {
    if (mousePressed) {
      delay(200);
      return mouseX / (width/7);
    }
    return -1;
  }
}

class MiniMaxAgent extends Player {

  final int depth = 10;
  final int MAX = 100000, MIN = -MAX;

  public MiniMaxAgent(Connect4Game g) {
    super(g);
  }

  public int getMove() {
    int[][] board = Helpers.copyMat(super.game.board);

    /*board = new int[][]{{0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0}, 
     {0, 0, 0, 0, 0, 0, 0}, 
     {1, 0, 0, 0, 0, 0, 1}, 
     {1, 1, 2, 2, 2, 0, 2}};*/

    int randMov = (int)(Math.random() * board[0].length);

    if (super.game.isEmpty()) {
      return randMov;
    }

    int highest = MIN;
    int high = randMov;
    println();
    for (int c = 0; c < board[0].length; c++) {
      if (board[0][c] == 0) {
        int r = Helpers.nextRow(board, c);
        board[r][c] = isRed ? 1:2;
        int score = alphabeta(board, depth, MIN, MAX, false);
        println(c + " " + score);
        if (score > highest) {
          high = c;
          highest = score;
        }
        board[r][c] = 0;
      }
    }
    println("->" + high);
    return high;
  }

  public int alphabeta(int[][] current, int depth, int alpha, int beta, boolean maxP) {
    if (depth == 0) {
      return eval(current);
    } else if (maxP) {
      int v = MIN;
      for (int c = 0; c < current[0].length; c++) {
        if (current[0][c] == 0) {
          int r = Helpers.nextRow(current, c);
          current[r][c] = isRed ? 1:2;
          v = max(v, alphabeta(current, depth - 1, alpha, beta, !maxP));
          current[r][c] = 0;
          alpha = max(alpha, v);
          if (beta <= alpha) {
            break;
          }
        }
      }
      return v;
    } else {
      int v = MAX;
      for (int c = 0; c < current[0].length; c++) {
        if (current[0][c] == 0) {
          int r = Helpers.nextRow(current, c);
          current[r][c] = isRed ? 2:1;
          v = min(v, alphabeta(current, depth - 1, alpha, beta, !maxP));
          current[r][c] = 0;
          beta = min(alpha, v);
          if (beta <= alpha) {
            break;
          }
        }
      }
      return v;
    }
  }

  public int eval(int[][] board) {
    int me = isRed ? 1 : 2;
    int them = isRed ? 2 : 1;

    int[] mePoints = new int[]{Helpers.mostVertical(board, me), Helpers.mostHorizontal(board, me), Helpers.mostIncDiag(board, me), Helpers.mostDecDiag(board, me)};
    int[] themPoints = new int[]{Helpers.mostVertical(board, them), Helpers.mostHorizontal(board, them), Helpers.mostIncDiag(board, them), Helpers.mostDecDiag(board, them)};

    if (Helpers.containsAtLeast(themPoints, 4)) {
      return MIN;
    }

    if (Helpers.containsAtLeast(mePoints, 4)) {
      return MAX;
    }

    int meScore = Helpers.sum(mePoints) * 20;
    int themScore = Helpers.sum(themPoints) * 20;

    meScore += Helpers.count(mePoints, 3) * 150;
    themScore += Helpers.count(themPoints, 3) * 200;

    return meScore - themScore;
  }
}

abstract class Player {
  boolean isRed;
  Connect4Game game;
  int wins;

  public Player(Connect4Game g) {
    this.game = g;
  }

  public abstract int getMove();

  public void setRed(boolean isR) {
    isRed = isR;
  }

  public String toString() {
    return isRed ? "Red":"Yellow";
  }
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Connect4Main" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
